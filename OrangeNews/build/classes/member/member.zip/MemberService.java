package member;

public class MemberService {
	MemberDAO memberDAO;

	public MemberService() {
		memberDAO=new MemberDAO();
	}
	
	public void logOut() {
		
	}
}
